"use client";

import Image from "next/image";
import {
  Activity,
  Aperture,
  ArrowRight,
  Bell,
  Bookmark,
  Camera,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clapperboard,
  Compass,
  Crown,
  Disc3,
  Ellipsis,
  ExternalLink,
  Film,
  Flame,
  Gamepad2,
  Globe2,
  Headphones,
  Heart,
  ImagePlus,
  Link2,
  ListMusic,
  LoaderCircle,
  Mail,
  Menu,
  MessageCircle,
  MessageSquare,
  Mic,
  Music2,
  Pause,
  PencilLine,
  Play,
  Plus,
  Radio,
  Search,
  Send,
  Settings2,
  Share2,
  Sparkles,
  Sun,
  TrendingUp,
  UserRoundPlus,
  Users,
  Video,
  Volume2,
  WandSparkles,
  X,
  type LucideIcon,
} from "lucide-react";
import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
} from "react";

type ViewKey =
  | "home"
  | "explore"
  | "messages"
  | "studio"
  | "camera"
  | "ai"
  | "inspiration"
  | "games"
  | "music"
  | "notifications"
  | "profile";

type Post = {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  time: string;
  text: string;
  image?: string;
  alt: string;
  tags: string[];
  likes: number;
  comments: number;
  persistent?: boolean;
};

type ApiPost = {
  id: string;
  authorName: string;
  authorHandle: string;
  avatarUrl: string;
  content: string;
  imageUrl: string | null;
  likes: number;
  createdAt: string;
};

type ChatMessage = {
  from: "me" | "them";
  text: string;
  time: string;
};

type Friend = {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  preview: string;
  time: string;
  online: boolean;
  unread?: number;
};

const PHOTO_1 =
  "https://images.pexels.com/photos/33271735/pexels-photo-33271735.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900";
const PHOTO_2 =
  "https://images.pexels.com/photos/5977862/pexels-photo-5977862.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900";
const PHOTO_3 =
  "https://images.pexels.com/photos/12810003/pexels-photo-12810003.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900";
const PHOTO_4 =
  "https://images.pexels.com/photos/30150602/pexels-photo-30150602.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900";
const PHOTO_5 =
  "https://images.pexels.com/photos/39567157/pexels-photo-39567157.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900";
const PHOTO_6 =
  "https://images.pexels.com/photos/14072086/pexels-photo-14072086.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900";
const PHOTOS = [PHOTO_1, PHOTO_2, PHOTO_3, PHOTO_4, PHOTO_5, PHOTO_6];
const DEFAULT_AVATAR = PHOTO_2;
const MY_AVATAR = PHOTO_3;

const INITIAL_POSTS: Post[] = [
  {
    id: "demo-1",
    name: "Luna Vale",
    handle: "luna.vale",
    avatar: PHOTO_2,
    time: "18 min ago",
    text: "Somewhere between the last train and the first light. A little reminder to keep looking up. ✦",
    image: PHOTO_1,
    alt: "A cinematic monochrome street portrait",
    tags: ["#afterhours", "#cityframes", "#noirportrait"],
    likes: 2840,
    comments: 128,
  },
  {
    id: "demo-2",
    name: "Kai Rivers",
    handle: "kai.rivers",
    avatar: PHOTO_5,
    time: "42 min ago",
    text: "A study in soft light and things left unsaid. Shot on the walk home.",
    image: PHOTO_4,
    alt: "An intimate black and white editorial portrait",
    tags: ["#quietmoments", "#filmfeels"],
    likes: 963,
    comments: 46,
  },
  {
    id: "demo-3",
    name: "Mika Sol",
    handle: "mika.sol",
    avatar: PHOTO_6,
    time: "1 hr ago",
    text: "New little series, ‘Between Takes’. The best frames always happen after the pose. ✨",
    image: PHOTO_3,
    alt: "A close-up black and white fashion photograph",
    tags: ["#betweenframes", "#portraitclub"],
    likes: 617,
    comments: 32,
  },
];

const STORIES = [
  { name: "Your story", image: MY_AVATAR, own: true },
  { name: "Luna", image: PHOTO_1 },
  { name: "Mika", image: PHOTO_6 },
  { name: "Kairo", image: PHOTO_5 },
  { name: "Nori", image: PHOTO_4 },
  { name: "Sage", image: PHOTO_2 },
  { name: "Remy", image: PHOTO_3 },
];

const FRIENDS: Friend[] = [
  {
    id: "noir-ai",
    name: "NOIR AI",
    handle: "your creative co-pilot",
    avatar: "",
    preview: "Here whenever inspiration hits.",
    time: "NOW",
    online: true,
  },
  {
    id: "luna",
    name: "Luna Vale",
    handle: "luna.vale",
    avatar: PHOTO_1,
    preview: "sent you a moodboard ✨",
    time: "2m",
    online: true,
    unread: 2,
  },
  {
    id: "kai",
    name: "Kai Rivers",
    handle: "kai.rivers",
    avatar: PHOTO_5,
    preview: "This is so your kind of light.",
    time: "18m",
    online: true,
  },
  {
    id: "mika",
    name: "Mika Sol",
    handle: "mika.sol",
    avatar: PHOTO_6,
    preview: "you: let’s shoot this weekend?",
    time: "1h",
    online: false,
  },
  {
    id: "remy",
    name: "Remy Arlo",
    handle: "remyarlo",
    avatar: PHOTO_2,
    preview: "Voice note · 0:14",
    time: "3h",
    online: false,
  },
  {
    id: "nori",
    name: "Nori James",
    handle: "norijames",
    avatar: PHOTO_4,
    preview: "thank you!! 🖤",
    time: "1d",
    online: false,
  },
];

const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  "noir-ai": [
    {
      from: "them",
      text: "Hey Amara — your creative co-pilot is here. Need a caption, a fresh concept, or just a second opinion?",
      time: "NOW",
    },
  ],
  luna: [
    { from: "them", text: "I found the perfect little corner for our shoot ✨", time: "10:42" },
    { from: "me", text: "Send it over, I’m already planning the fits.", time: "10:46" },
    { from: "them", text: "sent you a moodboard ✨", time: "10:49" },
  ],
  kai: [
    { from: "them", text: "This is so your kind of light.", time: "11:18" },
    { from: "me", text: "Right? Golden hour has main character energy.", time: "11:20" },
  ],
  mika: [{ from: "me", text: "let’s shoot this weekend?", time: "Yesterday" }],
  remy: [{ from: "them", text: "Voice note · 0:14", time: "Yesterday" }],
  nori: [{ from: "them", text: "thank you!! 🖤", time: "Monday" }],
};

const VIEW_DETAILS: Record<ViewKey, { title: string; eyebrow: string }> = {
  home: { title: "The daily edit", eyebrow: "YOUR WORLD, IN GOOD COMPANY" },
  explore: { title: "Find your next feeling", eyebrow: "DISCOVER SOMETHING NEW" },
  messages: { title: "A little more personal", eyebrow: "YOUR PRIVATE CORNER" },
  studio: { title: "Make it unmistakably yours", eyebrow: "NOIR STUDIO" },
  camera: { title: "See it your way", eyebrow: "NOIR CAMERA" },
  ai: { title: "Ideas look good on you", eyebrow: "MEET YOUR CREATIVE CO-PILOT" },
  inspiration: { title: "Save what moves you", eyebrow: "THE NOIR IDEA BOARD" },
  games: { title: "Take the scenic route", eyebrow: "PLAY A LITTLE" },
  music: { title: "Set the whole mood", eyebrow: "NOIR RADIO" },
  notifications: { title: "All caught up?", eyebrow: "YOUR LATEST ACTIVITY" },
  profile: { title: "Your world, your lens", eyebrow: "THE VIEW FROM HERE" },
};

const SOCIAL_LINKS = [
  { label: "Instagram", handle: "@amara.vale", href: "https://instagram.com/", symbol: "ig" },
  { label: "TikTok", handle: "@amara.frames", href: "https://tiktok.com/", symbol: "tk" },
  { label: "YouTube", handle: "Amara after hours", href: "https://youtube.com/", symbol: "yt" },
  { label: "Discord", handle: "Join my circle", href: "https://discord.com/", symbol: "dc" },
  { label: "Pinterest", handle: "Amara’s boards", href: "https://pinterest.com/", symbol: "p" },
  { label: "Spotify", handle: "On repeat lately", href: "https://spotify.com/", symbol: "♪" },
];

function timeLabel(value: string) {
  const minutes = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 60_000));
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
  return `${Math.floor(minutes / 1440)}d ago`;
}

function mapApiPost(post: ApiPost, localImage?: string): Post {
  return {
    id: post.id,
    name: post.authorName,
    handle: post.authorHandle,
    avatar: post.avatarUrl || MY_AVATAR,
    time: timeLabel(post.createdAt),
    text: post.content,
    image: localImage || post.imageUrl || undefined,
    alt: "A frame shared with the NOIR community",
    tags: ["#mynoir"],
    likes: post.likes,
    comments: 0,
    persistent: true,
  };
}

function Avatar({
  src,
  name,
  size = 40,
  className = "",
}: {
  src?: string;
  name: string;
  size?: number;
  className?: string;
}) {
  return (
    <span
      className={`avatar ${className}`}
      style={{ width: size, height: size, minWidth: size }}
      aria-label={name}
      title={name}
    >
      {src ? (
        <Image src={src} alt="" fill sizes={`${size}px`} unoptimized />
      ) : (
        <span className="avatar-initials">{name.slice(0, 1)}</span>
      )}
    </span>
  );
}

function IconButton({
  label,
  onClick,
  children,
  className = "",
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <button className={`icon-button ${className}`} type="button" aria-label={label} title={label} onClick={onClick}>
      {children}
    </button>
  );
}

function SidebarItem({
  icon: Icon,
  label,
  active,
  onClick,
  badge,
  accent,
}: {
  icon: LucideIcon;
  label: string;
  active: boolean;
  onClick: () => void;
  badge?: string;
  accent?: boolean;
}) {
  return (
    <button
      className={`sidebar-item ${active ? "is-active" : ""} ${accent ? "sidebar-item-accent" : ""}`}
      type="button"
      onClick={onClick}
    >
      <Icon size={18} strokeWidth={active ? 2.1 : 1.7} />
      <span>{label}</span>
      {badge ? <span className="nav-badge">{badge}</span> : null}
    </button>
  );
}

function FeedPost({
  post,
  liked,
  saved,
  onLike,
  onComment,
  onSave,
  onShare,
}: {
  post: Post;
  liked: boolean;
  saved: boolean;
  onLike: () => void;
  onComment: () => void;
  onSave: () => void;
  onShare: () => void;
}) {
  return (
    <article className="feed-card">
      <div className="post-header">
        <Avatar src={post.avatar} name={post.name} size={42} />
        <div className="post-byline">
          <div className="post-name-row">
            <span className="post-name">{post.name}</span>
            {post.handle === "amara.vale" ? <span className="verified-dot"><Check size={9} /></span> : null}
          </div>
          <span className="muted-line">@{post.handle} <span className="tiny-dot">·</span> {post.time}</span>
        </div>
        <button className="quiet-icon" type="button" aria-label="More post actions"><Ellipsis size={19} /></button>
      </div>
      {post.text ? <p className="post-copy">{post.text}</p> : null}
      {post.image ? (
        <div className="post-image">
          <Image src={post.image} alt={post.alt} fill sizes="(max-width: 700px) 94vw, 650px" unoptimized />
          <div className="photo-index"><Aperture size={12} /> FRAME NO. 04</div>
          <div className="photo-bottom-note"><span>NOIR / AFTER HOURS</span><span>35MM · 1/125</span></div>
        </div>
      ) : null}
      {post.tags.length > 0 ? (
        <div className="post-tags">{post.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
      ) : null}
      <div className="post-action-row">
        <button className={`post-action ${liked ? "is-liked" : ""}`} type="button" onClick={onLike} aria-label={liked ? "Unlike post" : "Like post"}>
          <Heart size={19} fill={liked ? "currentColor" : "none"} />
          <span>{compactNumber(post.likes + (liked ? 1 : 0))}</span>
        </button>
        <button className="post-action" type="button" onClick={onComment} aria-label="View comments">
          <MessageCircle size={19} /> <span>{compactNumber(post.comments)}</span>
        </button>
        <button className="post-action" type="button" onClick={onShare} aria-label="Share post"><Share2 size={18} /></button>
        <span className="action-spacer" />
        <button className={`post-action save-action ${saved ? "is-saved" : ""}`} type="button" onClick={onSave} aria-label={saved ? "Remove bookmark" : "Bookmark post"}>
          <Bookmark size={18} fill={saved ? "currentColor" : "none"} />
        </button>
      </div>
      {post.likes > 0 ? <div className="like-context"><span className="like-stack"><i>m</i><i>k</i><i>n</i></span><span>Liked by <b>mika.sol</b> and <b>{compactNumber(post.likes - 2)} others</b></span></div> : null}
    </article>
  );
}

function compactNumber(value: number) {
  if (value >= 1000) {
    const number = value / 1000;
    return `${number >= 10 ? number.toFixed(0) : number.toFixed(1).replace(/\.0$/, "")}k`;
  }
  return String(value);
}

function HomeView({
  posts,
  search,
  likedIds,
  savedIds,
  onLike,
  onComment,
  onSave,
  onShare,
  onCompose,
  onStory,
  onNavigate,
}: {
  posts: Post[];
  search: string;
  likedIds: Set<string>;
  savedIds: Set<string>;
  onLike: (id: string) => void;
  onComment: (post: Post) => void;
  onSave: (id: string) => void;
  onShare: (post: Post) => void;
  onCompose: () => void;
  onStory: (story: (typeof STORIES)[number]) => void;
  onNavigate: (view: ViewKey) => void;
}) {
  const [feedMode, setFeedMode] = useState("For you");
  const matchingPosts = posts.filter((post) =>
    `${post.name} ${post.handle} ${post.text} ${post.tags.join(" ")}`.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="content-columns">
      <section className="feed-column">
        <div className="feed-intro">
          <div>
            <div className="section-kicker"><span className="kicker-line" /> A PLACE FOR YOUR POINT OF VIEW</div>
            <h2>Make yourself <em>at home.</em></h2>
            <p>Little moments, big ideas, and the people who get it.</p>
          </div>
          <button className="round-gold-button" type="button" onClick={onCompose}><Plus size={17} /> Create</button>
        </div>

        <div className="story-shelf">
          <div className="shelf-heading"><span>Close to you</span><button type="button" onClick={() => onNavigate("explore")}>See everyone <ArrowRight size={13} /></button></div>
          <div className="story-list">
            {STORIES.map((story) => (
              <button className="story-item" key={story.name} type="button" onClick={() => onStory(story)}>
                <span className={`story-ring ${story.own ? "story-own" : ""}`}>
                  <Avatar src={story.image} name={story.name} size={52} />
                  {story.own ? <span className="story-plus"><Plus size={11} /></span> : null}
                </span>
                <span className="story-name">{story.name}</span>
              </button>
            ))}
          </div>
        </div>

        <button className="quick-composer" type="button" onClick={onCompose}>
          <Avatar src={MY_AVATAR} name="Amara Vale" size={40} />
          <span className="composer-placeholder">What’s on your mind, Amara?</span>
          <span className="composer-media"><ImagePlus size={17} /><span>Photo</span></span>
        </button>

        <div className="feed-filter-row">
          <div className="feed-tabs">
            {["For you", "Following", "Saved"].map((mode) => (
              <button className={feedMode === mode ? "selected" : ""} key={mode} type="button" onClick={() => setFeedMode(mode)}>{mode}</button>
            ))}
          </div>
          <button className="filter-button" type="button" onClick={() => onNavigate("explore")}><Settings2 size={15} /> Filters</button>
        </div>

        <div className="feed-stream">
          {(feedMode === "Saved" ? matchingPosts.filter((post) => savedIds.has(post.id)) : matchingPosts).map((post) => (
            <FeedPost
              key={post.id}
              post={post}
              liked={likedIds.has(post.id)}
              saved={savedIds.has(post.id)}
              onLike={() => onLike(post.id)}
              onComment={() => onComment(post)}
              onSave={() => onSave(post.id)}
              onShare={() => onShare(post)}
            />
          ))}
          {matchingPosts.length === 0 ? (
            <div className="empty-state"><Search size={22} /><strong>No frames found</strong><span>Try another name, tag, or little idea.</span></div>
          ) : null}
          {feedMode === "Saved" && matchingPosts.filter((post) => savedIds.has(post.id)).length === 0 ? (
            <div className="empty-state"><Bookmark size={22} /><strong>Your saved corner is waiting</strong><span>Bookmark a post to keep it close.</span></div>
          ) : null}
          <button className="load-more-button" type="button" onClick={() => onNavigate("explore")}>You’re all caught up <span>Find something new <ArrowRight size={14} /></span></button>
        </div>
      </section>

      <aside className="right-rail">
        <div className="ai-side-card">
          <div className="ai-orbit"><Sparkles size={19} /></div>
          <div className="mini-kicker">A LITTLE CREATIVE MAGIC</div>
          <h3>Meet your new<br />favorite co-creator.</h3>
          <p>Brainstorm, dream out loud, and turn that “what if” into something real.</p>
          <button type="button" onClick={() => onNavigate("ai")}>Talk to NOIR AI <ArrowRight size={15} /></button>
          <div className="ai-card-glow" />
        </div>

        <div className="rail-card trend-card">
          <div className="rail-heading"><div><span className="rail-eyebrow">THE CREATIVE PULSE</span><h3>On the moodboard</h3></div><TrendingUp size={17} /></div>
          <button className="trend-row" type="button" onClick={() => onNavigate("explore")}><span className="trend-number">01</span><span><b>#slowframes</b><small>2.8k frames this week</small></span><ArrowRight size={14} /></button>
          <button className="trend-row" type="button" onClick={() => onNavigate("explore")}><span className="trend-number">02</span><span><b>Sunday in silver</b><small>Visual story · 18.2k saves</small></span><ArrowRight size={14} /></button>
          <button className="trend-row" type="button" onClick={() => onNavigate("inspiration")}><span className="trend-number">03</span><span><b>#afterhoursclub</b><small>1.4k people creating</small></span><ArrowRight size={14} /></button>
          <button className="text-link" type="button" onClick={() => onNavigate("explore")}>Explore what’s moving <ArrowRight size={13} /></button>
        </div>

        <div className="rail-card creator-card">
          <div className="rail-heading"><div><span className="rail-eyebrow">YOUR PEOPLE</span><h3>Creators to know</h3></div><button type="button" aria-label="View all creators" onClick={() => onNavigate("explore")}><ArrowRight size={16} /></button></div>
          {[
            { name: "Nori James", handle: "norijames", image: PHOTO_4 },
            { name: "Mika Sol", handle: "mika.sol", image: PHOTO_6 },
          ].map((person) => (
            <div className="suggestion-row" key={person.handle}><Avatar src={person.image} name={person.name} size={38} /><span className="suggestion-details"><b>{person.name}</b><small>@{person.handle}</small></span><button className="small-follow" type="button" onClick={() => onNavigate("explore")} aria-label={`Discover ${person.name}`}><Plus size={15} /></button></div>
          ))}
        </div>

        <div className="rail-social-note"><span className="gold-orb"><Aperture size={14} /></span><span>One world for all the things<br />you love to make.</span><button type="button" onClick={() => onNavigate("profile")}>Your profile <ArrowRight size={12} /></button></div>
        <div className="rail-footer">About <span>·</span> Guidelines <span>·</span> Privacy <span>·</span> © NOIR 2025</div>
      </aside>
    </div>
  );
}

function ExploreView({ onToast, savedIds, onSave }: { onToast: (message: string) => void; savedIds: Set<string>; onSave: (id: string) => void }) {
  const [category, setCategory] = useState("For you");
  const [following, setFollowing] = useState<string[]>(["kai.rivers"]);
  const [search, setSearch] = useState("");
  const categories = ["For you", "Photography", "Style", "Interiors", "Portraits", "Film"];
  const gallery = [
    { id: "explore-1", image: PHOTO_1, title: "Somewhere after midnight", creator: "Luna Vale", category: "Photography", tall: true },
    { id: "explore-2", image: PHOTO_4, title: "The in-between", creator: "Nori James", category: "Portraits", tall: false },
    { id: "explore-3", image: PHOTO_5, title: "An honest kind of light", creator: "Kai Rivers", category: "Style", tall: true },
    { id: "explore-4", image: PHOTO_2, title: "Room for a daydream", creator: "Remy Arlo", category: "Film", tall: false },
    { id: "explore-5", image: PHOTO_6, title: "No perfect angles", creator: "Mika Sol", category: "Photography", tall: true },
    { id: "explore-6", image: PHOTO_3, title: "Quietly becoming", creator: "Amara Vale", category: "Style", tall: false },
  ];
  const filtered = gallery.filter((item) => {
    const categoryMatch = category === "For you" || category === "Interiors" || item.category === category;
    const queryMatch = `${item.title} ${item.creator} ${item.category}`.toLowerCase().includes(search.toLowerCase());
    return categoryMatch && queryMatch;
  });
  const creators = [
    { name: "Nori James", handle: "norijames", image: PHOTO_4, label: "Portraits · Seoul" },
    { name: "Luna Vale", handle: "luna.vale", image: PHOTO_1, label: "Film · Brooklyn" },
    { name: "Mika Sol", handle: "mika.sol", image: PHOTO_6, label: "Style · Toronto" },
  ];

  return (
    <div className="page-content explore-page">
      <div className="explore-hero">
        <Image src={PHOTO_5} alt="A moody black and white portrait" fill sizes="100vw" unoptimized />
        <div className="explore-hero-shade" />
        <div className="explore-hero-copy"><span className="mini-kicker">THE NOIR DISCOVER EDIT · 01</span><h2>Find the thing<br />you didn’t know<br /><em>you were looking for.</em></h2><button type="button" onClick={() => setCategory("Photography")}>Explore the edit <ArrowRight size={15} /></button></div>
        <div className="explore-hero-count">01 <span>/ 06</span></div>
      </div>
      <div className="discover-search-row"><div className="big-search"><Search size={17} /><input aria-label="Search creators and inspiration" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search people, moods, and little obsessions" /><kbd>⌘ K</kbd></div><button className="filter-button" type="button" onClick={() => onToast("Your discover preferences are up to date.")}><Settings2 size={16} /> Preferences</button></div>
      <div className="category-chips">{categories.map((item) => <button className={category === item ? "active" : ""} key={item} type="button" onClick={() => setCategory(item)}>{item}</button>)}</div>
      <section className="explore-section"><div className="section-heading"><div><span className="rail-eyebrow">A FEW GOOD FINDS</span><h3>Made by the community</h3></div><button className="text-link" type="button" onClick={() => setCategory("For you")}>See all <ArrowRight size={14} /></button></div>
        <div className="explore-grid">{filtered.map((item) => <article className={`explore-tile ${item.tall ? "tile-tall" : ""}`} key={item.id}><div className="tile-image"><Image src={item.image} alt={item.title} fill sizes="(max-width: 700px) 45vw, 300px" unoptimized /><button className="tile-save" type="button" onClick={() => { onSave(item.id); onToast(savedIds.has(item.id) ? "Removed from your saved ideas." : "Saved to your inspiration board."); }} aria-label="Save inspiration"><Bookmark size={17} fill={savedIds.has(item.id) ? "currentColor" : "none"} /></button><div className="tile-overlay"><span>{item.category}</span><h4>{item.title}</h4><small>by {item.creator}</small></div></div></article>)}</div>
      </section>
      <section className="explore-section creator-discovery"><div className="section-heading"><div><span className="rail-eyebrow">GOOD PEOPLE, GOOD IDEAS</span><h3>Creators you might love</h3></div><button className="text-link" type="button" onClick={() => onToast("You’ve reached the end of this week’s picks.")}>Meet everyone <ArrowRight size={14} /></button></div><div className="creator-cards">{creators.map((creator) => { const isFollowing = following.includes(creator.handle); return <article className="creator-discovery-card" key={creator.handle}><Avatar src={creator.image} name={creator.name} size={54} /><div><b>{creator.name}</b><small>@{creator.handle}</small><small>{creator.label}</small></div><button className={isFollowing ? "following-button" : "follow-button"} type="button" onClick={() => setFollowing((current) => isFollowing ? current.filter((handle) => handle !== creator.handle) : [...current, creator.handle])}>{isFollowing ? <><Check size={13} /> Following</> : <><UserRoundPlus size={14} /> Follow</>}</button></article>; })}</div></section>
    </div>
  );
}

function MessagesView({ onToast }: { onToast: (message: string) => void }) {
  const [activeId, setActiveId] = useState("luna");
  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>(() => ({ ...INITIAL_MESSAGES }));
  const [aiTyping, setAiTyping] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const friend = FRIENDS.find((item) => item.id === activeId) ?? FRIENDS[1];
  const filteredFriends = FRIENDS.filter((item) => `${item.name} ${item.handle}`.toLowerCase().includes(search.toLowerCase()));
  const conversation = messages[activeId] ?? [];

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [conversation.length, activeId]);

  function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = draft.trim();
    if (!text) return;
    const threadId = activeId;
    const history: ChatMessage[] = [...(messages[threadId] ?? []), { from: "me", text, time: "NOW" }];
    setMessages((current) => ({ ...current, [threadId]: history }));
    setDraft("");
    const deliver = (reply: string) =>
      setMessages((current) => ({ ...current, [threadId]: [...(current[threadId] ?? []), { from: "them", text: reply, time: "NOW" }] }));
    if (threadId === "noir-ai") {
      setAiTyping(true);
      void askNoirAi(history).then((result) => {
        deliver(result.reply);
        setAiTyping(false);
      });
      return;
    }
    window.setTimeout(() => {
      deliver(["I love this. Tell me more ✨", "That sounds like such a good idea.", "On my way to save this in my brain 🖤"][Math.floor(Math.random() * 3)]);
    }, 850);
  }

  return (
    <div className="messages-page page-content">
      <section className="messages-layout">
        <aside className="dm-sidebar">
          <div className="dm-heading"><div><span className="rail-eyebrow">THE QUIET CORNER</span><h2>Messages <span>04</span></h2></div><button className="compose-dm" type="button" aria-label="New message" onClick={() => onToast("Choose a creator from your list to start a conversation.")}><PencilLine size={17} /></button></div>
          <div className="dm-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search messages" aria-label="Search messages" /><kbd>⌘ K</kbd></div>
          <button className={`ai-friend-card ${activeId === "noir-ai" ? "active" : ""}`} type="button" onClick={() => setActiveId("noir-ai")}><span className="ai-avatar"><Sparkles size={19} /></span><span><b>NOIR AI</b><small>Creative co-pilot · Always here</small></span><span className="online-dot" /></button>
          <div className="dm-list-label">YOUR PEOPLE <button type="button" onClick={() => onToast("Your friend list is up to date.")}><ChevronDown size={14} /></button></div>
          <div className="friend-list">{filteredFriends.filter((item) => item.id !== "noir-ai").map((item) => (
            <button className={`friend-row ${activeId === item.id ? "active" : ""}`} key={item.id} type="button" onClick={() => setActiveId(item.id)}><span className="friend-avatar-wrap"><Avatar src={item.avatar} name={item.name} size={43} />{item.online ? <i className="online-dot" /> : null}</span><span className="friend-copy"><b>{item.name}</b><small>{item.preview}</small></span><span className="friend-time">{item.time}{item.unread ? <i>{item.unread}</i> : null}</span></button>
          ))}{filteredFriends.filter((item) => item.id !== "noir-ai").length === 0 ? <div className="friend-empty">No conversations found.</div> : null}</div>
          <button className="find-friends-link" type="button" onClick={() => onToast("Discover new people in the Explore tab.")}><Users size={15} /> Find more people <ArrowRight size={13} /></button>
        </aside>
        <section className="chat-panel">
          <header className="chat-header"><div className="chat-person">{friend.id === "noir-ai" ? <span className="ai-avatar small"><Sparkles size={17} /></span> : <span className="friend-avatar-wrap"><Avatar src={friend.avatar} name={friend.name} size={42} />{friend.online ? <i className="online-dot" /> : null}</span>}<div><b>{friend.name}</b><small>{friend.id === "noir-ai" ? "Your creative co-pilot" : friend.online ? "Active now" : `@${friend.handle}`}</small></div></div><div className="chat-header-actions"><button type="button" aria-label="Start voice call" onClick={() => onToast("Voice calls will be available when NOIR accounts are connected.")}><Mic size={18} /></button><button type="button" aria-label="Start video call" onClick={() => onToast("Video calls are a preview feature in this prototype.")}><Video size={19} /></button><button type="button" aria-label="Conversation details" onClick={() => onToast("Conversation details are looking good.")}><Ellipsis size={19} /></button></div></header>
          {friend.id === "noir-ai" ? <div className="chat-ai-note"><Sparkles size={13} /> Ask NOIR AI anything — ideas, captions, code, plans, or a second opinion.</div> : null}
          <div className="chat-date-line"><span />TODAY<span /></div>
          <div className="chat-messages" ref={listRef}>{conversation.map((message, index) => <div className={`message-line ${message.from === "me" ? "mine" : "theirs"}`} key={`${message.time}-${index}`}><div className="message-bubble">{message.text}<small>{message.time} {message.from === "me" ? <CheckCheck size={12} /> : null}</small></div></div>)}{friend.id === "noir-ai" && aiTyping ? <div className="thinking-line"><span /><span /><span /> NOIR is thinking…</div> : null}</div>
          <form className="chat-compose" onSubmit={sendMessage}><button className="chat-attach" type="button" aria-label="Attach a photo" onClick={() => onToast("Photo sharing is available in this conversation preview.")}><Plus size={18} /></button><input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={`Message ${friend.id === "noir-ai" ? "your co-pilot" : friend.name.split(" ")[0]}…`} aria-label="Write a message" /><button className="chat-emoji" type="button" aria-label="Add a sparkle" onClick={() => setDraft((value) => `${value} ✨`)}>✦</button><button className="send-button" type="submit" aria-label="Send message"><Send size={17} /></button></form>
          <p className="chat-safety-note"><LockIcon /> Your conversations are just for you.</p>
        </section>
      </section>
    </div>
  );
}

function LockIcon() {
  return <span className="lock-symbol">⌑</span>;
}

function aiReply(prompt: string) {
  const value = prompt.toLowerCase();
  if (value.includes("caption") || value.includes("post")) return "Try this: ‘The city kept its secrets. I kept the frame.’ ✦ Want something softer, funnier, or a little more cinematic?";
  if (value.includes("idea") || value.includes("shoot") || value.includes("photo")) return "Let’s make a tiny concept: one subject, one window of late-afternoon light, and a reflection you almost missed. Keep it close, honest, and a little imperfect.";
  if (value.includes("playlist") || value.includes("music")) return "Set the scene with slow-burn R&B, a little dream pop, then one song that sounds like driving home at 1 a.m. I can help you shape the mood from there.";
  return "I’m listening. Let’s start with what you want someone to feel when they see it — then we can find the words, colors, and little details that get us there. ✨";
}

let demoHintShown = false;

async function askNoirAi(history: ChatMessage[]): Promise<{ reply: string; live: boolean }> {
  const lastUser = [...history].reverse().find((message) => message.from === "me")?.text ?? "";
  try {
    const response = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: history.map((message) => ({
          role: message.from === "me" ? "user" : "assistant",
          content: message.text,
        })),
      }),
    });
    const data = (await response.json()) as { live?: boolean; reply?: string | null; error?: string };
    if (data.reply) return { reply: data.reply, live: true };
    if (data.live && data.error) return { reply: data.error, live: true };
  } catch {
    // fall through to the offline companion
  }
  return { reply: aiReply(lastUser), live: false };
}

function AiView({ onToast }: { onToast: (message: string) => void }) {
  const [messages, setMessages] = useState<ChatMessage[]>([{ from: "them", text: "Hey Amara. Bring me the half-formed thought, the impossible brief, or the idea you’ve been saving for later. We’ll make something of it. ✦", time: "NOW" }]);
  const [draft, setDraft] = useState("");
  const [thinking, setThinking] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const prompts = ["Help me dream up a photo series", "Write a caption for this feeling", "Find a color palette for golden hour", "Give me a creative reset"];

  useEffect(() => listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" }), [messages.length, thinking]);

  function ask(prompt: string) {
    const text = prompt.trim();
    if (!text || thinking) return;
    const history: ChatMessage[] = [...messages, { from: "me", text, time: "NOW" }];
    setMessages(history);
    setDraft("");
    setThinking(true);
    void askNoirAi(history).then((result) => {
      setMessages((current) => [...current, { from: "them", text: result.reply, time: "NOW" }]);
      setThinking(false);
      if (!result.live && !demoHintShown) {
        demoHintShown = true;
        onToast("NOIR AI is in demo mode. Add an AI API key to unlock full intelligence.");
      }
    });
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    ask(draft);
  }

  return (
    <div className="page-content ai-page">
      <section className="ai-workspace">
        <aside className="ai-intro-panel"><div className="ai-large-mark"><Sparkles size={25} /></div><span className="rail-eyebrow">A CREATIVE SPACE, JUST FOR YOU</span><h2>Good ideas<br />start with <em>what if.</em></h2><p>Talk it out. Get unstuck. Find the words. NOIR AI is a little spark for whatever you’re making.</p><div className="ai-capability-list"><span><PencilLine size={15} /> Creative writing</span><span><Aperture size={15} /> Visual concepts</span><span><Music2 size={15} /> Mood & ideas</span></div><div className="ai-demo-disclaimer"><Sparkles size={13} /> Powered by a large language model when connected</div><div className="ai-intro-flare" /></aside>
        <section className="ai-conversation"><div className="ai-conversation-head"><div className="ai-avatar"><Sparkles size={18} /></div><div><b>NOIR AI</b><small><i className="online-dot" /> HERE WHEN YOU NEED A SPARK</small></div><button type="button" onClick={() => { setMessages([{ from: "them", text: "Fresh page. What are we dreaming up? ✦", time: "NOW" }]); onToast("A fresh conversation, just like that."); }} aria-label="Start a new conversation"><PencilLine size={16} /></button></div><div className="ai-thread" ref={listRef}>{messages.map((message, index) => <div className={`message-line ${message.from === "me" ? "mine" : "theirs"}`} key={`${index}-${message.text}`}><div className="message-bubble">{message.text}<small>{message.time} {message.from === "me" ? <CheckCheck size={12} /> : <Sparkles size={11} />}</small></div></div>)}{thinking ? <div className="thinking-line"><span /><span /><span /> NOIR is finding the words…</div> : null}</div>{messages.length === 1 ? <div className="prompt-starters"><span>A FEW PLACES TO BEGIN</span>{prompts.map((prompt) => <button key={prompt} type="button" onClick={() => ask(prompt)}><Sparkles size={13} />{prompt}<ArrowRight size={13} /></button>)}</div> : null}<form className="ai-input-row" onSubmit={handleSubmit}><input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Tell me what’s on your mind…" aria-label="Message NOIR AI" /><button type="button" aria-label="Add an idea" onClick={() => setDraft((value) => `${value} ✦`)}><Plus size={17} /></button><button className="send-button" type="submit" aria-label="Send to NOIR AI" disabled={thinking}><Send size={17} /></button></form><p className="ai-input-note">A friendly creative tool, not a substitute for professional advice.</p></section>
      </section>
    </div>
  );
}

function StudioView({ onToast }: { onToast: (message: string) => void }) {
  const [mode, setMode] = useState("Photo");
  const [filter, setFilter] = useState("Afterglow");
  const [intensity, setIntensity] = useState(72);
  const [adjustment, setAdjustment] = useState("Light");
  const filters = ["Afterglow", "Silver 02", "Soft focus", "Warmth", "Nocturne", "No filter"];
  const filterStyle = filter === "Silver 02" ? "grayscale(1) contrast(1.08)" : filter === "Nocturne" ? "grayscale(.8) contrast(1.18) brightness(.83)" : filter === "Afterglow" ? "sepia(.2) saturate(1.13)" : filter === "Soft focus" ? "contrast(.9) brightness(1.06)" : filter === "Warmth" ? "sepia(.28) saturate(1.22)" : "none";

  return (
    <div className="page-content studio-page"><div className="studio-toolbar"><div className="studio-file"><span className="studio-file-icon"><ImagePlus size={16} /></span><div><b>Untitled session</b><small>Last edited just now · draft</small></div><ChevronDown size={15} /></div><div className="studio-actions"><button type="button" className="subtle-button" onClick={() => onToast("Your edit is saved as a draft.")}><Bookmark size={15} /> Save draft</button><button type="button" className="gold-button" onClick={() => onToast("Export preview ready — connect storage to download your full edit.")}>Export <ArrowRight size={15} /></button></div></div>
      <div className="studio-workspace"><section className="studio-canvas-panel"><div className="canvas-toolbar"><div className="studio-mode-tabs">{["Photo", "Video"].map((item) => <button className={mode === item ? "active" : ""} key={item} type="button" onClick={() => setMode(item)}>{item === "Photo" ? <Aperture size={14} /> : <Film size={14} />}{item}</button>)}</div><span>1080 × 1350 <i /> 4:5</span><div><button type="button" aria-label="Zoom out" onClick={() => onToast("Canvas zoom set to fit.")}>−</button><b>84%</b><button type="button" aria-label="Zoom in" onClick={() => onToast("Canvas zoom set to 100%.")}>+</button></div></div><div className="studio-canvas"><div className="canvas-image"><Image src={PHOTO_1} alt="NOIR Studio portrait preview" fill sizes="(max-width: 900px) 90vw, 700px" unoptimized style={{ filter: filterStyle }} /><div className="canvas-corner-tag">NOIR STUDIO <span>·</span> {filter.toUpperCase()}</div><div className="canvas-center-mark"><Aperture size={20} /></div><div className="canvas-side-label">FRAME 001 — EDITING</div></div></div><div className="film-strip"><span className="film-strip-label">YOUR MEDIA</span>{PHOTOS.slice(0, 4).map((image, index) => <button className={`film-thumb ${index === 0 ? "selected" : ""}`} key={image} type="button" onClick={() => onToast(`Frame ${String(index + 1).padStart(2, "0")} selected.`)}><Image src={image} alt={`Media frame ${index + 1}`} fill sizes="70px" unoptimized /></button>)}<button className="add-media-thumb" type="button" onClick={() => onToast("Add a photo or clip from your camera roll.")}><Plus size={18} /><span>Add media</span></button></div></section>
        <aside className="studio-controls"><div className="controls-heading"><div><span className="rail-eyebrow">THE FINER DETAILS</span><h3>Make it yours.</h3></div><button type="button" aria-label="Reset adjustments" onClick={() => { setIntensity(72); setFilter("Afterglow"); onToast("Adjustments reset."); }}><Settings2 size={16} /></button></div><div className="control-tabs">{["Looks", "Adjust", "Effects"].map((item) => <button className={adjustment === item ? "active" : ""} type="button" key={item} onClick={() => setAdjustment(item)}>{item}</button>)}</div>{adjustment === "Looks" ? <><div className="control-label-row"><span>FILTERS <small>100+ looks</small></span><button type="button" onClick={() => onToast("All 100+ looks are ready to explore.")}>SEE ALL <ArrowRight size={11} /></button></div><div className="filter-grid">{filters.map((item, index) => <button className={`filter-tile ${filter === item ? "active" : ""}`} key={item} type="button" onClick={() => setFilter(item)}><span className={`filter-preview fp-${index}`} style={{ backgroundImage: `url(${PHOTOS[index % PHOTOS.length]})` }} />{item}{filter === item ? <Check size={11} /> : null}</button>)}</div></> : adjustment === "Adjust" ? <div className="adjustment-list">{["Exposure", "Contrast", "Highlights", "Shadows", "Temperature", "Grain"].map((item, index) => <label className="adjustment-slider" key={item}><span>{item}<small>{index === 0 ? "+0.4" : index === 3 ? "−0.2" : "0"}</small></span><input type="range" min="0" max="100" defaultValue={index === 0 ? 62 : 50} aria-label={item} /></label>)}</div> : <div className="effect-list">{["Soft grain", "Light leak", "Motion blur", "Film dust", "Chromatic shift"].map((item) => <button type="button" key={item} onClick={() => { setFilter(item === "Soft grain" ? "Silver 02" : "Afterglow"); onToast(`${item} added to your edit.`); }}><span><Sparkles size={14} /></span>{item}<Plus size={14} /></button>)}</div>}<div className="intensity-control"><div><span>Intensity</span><b>{intensity}%</b></div><input type="range" min="0" max="100" value={intensity} onChange={(event) => setIntensity(Number(event.target.value))} aria-label="Effect intensity" /></div><div className="template-callout"><div className="template-art"><Image src={PHOTO_5} alt="Template preview" fill sizes="100px" unoptimized /></div><div><span className="rail-eyebrow">A GOOD PLACE TO START</span><b>Midnight, in motion</b><small>Template · 00:18</small></div><button type="button" aria-label="Use template" onClick={() => onToast("Midnight, in motion template applied.")}><ArrowRight size={15} /></button></div></aside></div>
    </div>
  );
}

function CameraView({ onToast }: { onToast: (message: string) => void }) {
  const [filter, setFilter] = useState("Original");
  const [zoom, setZoom] = useState(1);
  const [preview, setPreview] = useState<string | null>(null);
  const [timer, setTimer] = useState("Off");
  const [flash, setFlash] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const cameraFilter = filter === "Noir" ? "grayscale(1) contrast(1.13)" : filter === "Gold" ? "sepia(.35) saturate(1.18)" : filter === "Fade" ? "contrast(.84) brightness(1.13)" : "none";

  function choosePhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
      onToast("Your frame is ready for the studio.");
    }
  }

  function capture() {
    setFlash(true);
    window.setTimeout(() => setFlash(false), 180);
    onToast("Beautiful. Captured in preview mode — bring your own camera roll to save a frame.");
  }

  return (
    <div className="page-content camera-page"><div className="camera-layout"><section className="camera-stage"><div className="camera-top-tools"><span className="camera-mode-pill"><span /> {preview ? "FRAME PREVIEW" : "PHOTO MODE"}</span><div><button type="button" onClick={() => setTimer((current) => current === "Off" ? "3s" : current === "3s" ? "10s" : "Off")}><span className="timer-icon">◷</span> {timer}</button><button type="button" onClick={() => onToast("Flash set to auto.")}><Sun size={16} /></button><button type="button" onClick={() => onToast("Grid overlay toggled.")}>▦</button></div></div><div className="camera-viewfinder"><Image src={preview || PHOTO_4} alt="Camera viewfinder preview" fill sizes="(max-width: 900px) 100vw, 900px" unoptimized style={{ filter: cameraFilter, transform: `scale(${zoom})` }} /><div className="viewfinder-grid"><span /><span /><span /><span /><span /><span /><span /><span /><span /></div><div className="focus-square" /><div className="camera-watermark">NOIR <span>·</span> YOUR WORLD, YOUR LENS</div>{flash ? <div className="capture-flash" /> : null}</div><div className="camera-bottom-controls"><button className="camera-last-shot" type="button" onClick={() => fileInput.current?.click()} aria-label="Choose a photo"><Image src={preview || PHOTO_6} alt="Open your camera roll" fill sizes="60px" unoptimized /></button><div className="shutter-wrap"><button className="shutter-button" type="button" onClick={capture} aria-label="Capture photo"><span /></button><span>CAPTURE</span></div><button className="camera-switch" type="button" onClick={() => setZoom((current) => current === 1 ? 1.6 : 1)} aria-label="Toggle zoom"><span>{zoom === 1 ? "1×" : "1.6×"}</span></button></div><input ref={fileInput} type="file" accept="image/*" capture="environment" className="visually-hidden" onChange={choosePhoto} /></section><aside className="camera-side-panel"><span className="rail-eyebrow">FIND YOUR LIGHT</span><h3>A little frame<br />of <em>your own.</em></h3><p>Small moments deserve a point of view. Pick a look, find a little light, and see what happens.</p><div className="camera-filter-heading"><span>QUICK LOOKS</span><button type="button" onClick={() => onToast("100 creative looks, one very good camera.")}>100 effects <ArrowRight size={12} /></button></div><div className="camera-filters">{["Original", "Noir", "Gold", "Fade"].map((item, index) => <button className={filter === item ? "active" : ""} key={item} type="button" onClick={() => setFilter(item)}><span className={`camera-filter-thumb camera-filter-${index}`} style={{ backgroundImage: `url(${PHOTOS[index]})` }} />{item}</button>)}</div><div className="camera-control-row"><span><Aperture size={16} /> Focus</span><input type="range" min="1" max="3" defaultValue="2" aria-label="Camera focus" /></div><div className="camera-control-row"><span><Volume2 size={16} /> Exposure</span><input type="range" min="0" max="100" defaultValue="56" aria-label="Camera exposure" /></div><button className="import-camera-button" type="button" onClick={() => fileInput.current?.click()}><ImagePlus size={16} /> Import from camera roll <ArrowRight size={14} /></button><div className="camera-note"><Sparkles size={14} /> Photo capture and effects are a visual demo. Select an image to bring it into your workspace.</div></aside></div></div>
  );
}

function InspirationView({ onToast, savedIds, onSave }: { onToast: (message: string) => void; savedIds: Set<string>; onSave: (id: string) => void }) {
  const [board, setBoard] = useState("All ideas");
  const boards = ["All ideas", "Outfits", "Portraits", "Places", "Color stories"];
  const items = [
    { id: "idea-1", image: PHOTO_1, title: "The city after rain", creator: "Luna Vale", ratio: "idea-tall", label: "PHOTOGRAPHY" },
    { id: "idea-2", image: PHOTO_5, title: "A soft place to land", creator: "Kai Rivers", ratio: "idea-short", label: "STYLE" },
    { id: "idea-3", image: PHOTO_6, title: "Sunday, slowly", creator: "Mika Sol", ratio: "idea-medium", label: "PORTRAITS" },
    { id: "idea-4", image: PHOTO_2, title: "Silver screen feeling", creator: "Remy Arlo", ratio: "idea-tall", label: "COLOR STORY" },
    { id: "idea-5", image: PHOTO_4, title: "One frame to remember", creator: "Nori James", ratio: "idea-medium", label: "PHOTOGRAPHY" },
    { id: "idea-6", image: PHOTO_3, title: "Before the world wakes", creator: "Amara Vale", ratio: "idea-short", label: "OUTFITS" },
  ];
  const filtered = items.filter((item) => board === "All ideas" || item.label.toLowerCase().includes(board.replace(/s$/, "").toLowerCase()) || (board === "Portraits" && item.label === "PORTRAITS"));
  return (
    <div className="page-content inspiration-page"><div className="ideas-hero"><div><span className="rail-eyebrow">COLLECT THE LITTLE THINGS</span><h2>Curiosity looks<br /><em>good on you.</em></h2><p>Outfits, backdrops, light, and all the lovely things you haven’t made yet.</p><button className="gold-button" type="button" onClick={() => onToast("A new board is ready for your next idea.")}><Plus size={15} /> Make a board</button></div><div className="ideas-hero-images"><div><Image src={PHOTO_1} alt="Portrait inspiration" fill sizes="180px" unoptimized /></div><div><Image src={PHOTO_6} alt="Fashion inspiration" fill sizes="180px" unoptimized /></div><span>YOUR NEXT<br />BIG LITTLE IDEA</span></div></div><div className="board-tabs">{boards.map((item) => <button className={board === item ? "active" : ""} key={item} type="button" onClick={() => setBoard(item)}>{item}</button>)}<button className="board-manage" type="button" onClick={() => onToast("Your boards are organized and ready.")}><Settings2 size={15} /> Manage</button></div><div className="ideas-masonry">{filtered.map((item) => <article className={`idea-card ${item.ratio}`} key={item.id}><div className="idea-image"><Image src={item.image} alt={item.title} fill sizes="(max-width: 700px) 48vw, 300px" unoptimized /><span className="idea-category">{item.label}</span><button className={`idea-save ${savedIds.has(item.id) ? "saved" : ""}`} type="button" onClick={() => { onSave(item.id); onToast(savedIds.has(item.id) ? "Removed from saved ideas." : "Pinned to your ideas."); }} aria-label="Save idea"><Bookmark size={16} fill={savedIds.has(item.id) ? "currentColor" : "none"} /></button><div className="idea-image-caption"><b>{item.title}</b><span>by {item.creator}</span></div></div><div className="idea-card-meta"><span><Avatar src={PHOTO_2} name="Luna Vale" size={22} /> Inspired by the community</span><button type="button" onClick={() => onToast("Idea link copied to your clipboard.")} aria-label="Share idea"><Share2 size={15} /></button></div></article>)}</div><div className="ideas-footnote"><Sparkles size={15} /> Good ideas are contagious. Credit the creator when you bring one to life.</div></div>
  );
}

function GamesView({ onToast }: { onToast: (message: string) => void }) {
  const [category, setCategory] = useState("All games");
  const [search, setSearch] = useState("");
  const [playing, setPlaying] = useState<string | null>(null);
  const games = [
    { id: "afterglow", title: "Afterglow", genre: "ARCADE · 1 PLAYER", image: PHOTO_1, mark: "A", color: "#7b5a3c", description: "Chase the last warm light." },
    { id: "little-planet", title: "Little Planet", genre: "PUZZLE · 1 PLAYER", image: PHOTO_6, mark: "✳", color: "#6b705b", description: "Build a softer somewhere." },
    { id: "midnight-club", title: "Midnight Club", genre: "RHYTHM · 2 PLAYERS", image: PHOTO_5, mark: "◉", color: "#543747", description: "Find your way through the beat." },
    { id: "still-life", title: "Still Life", genre: "CREATIVE · SOLO", image: PHOTO_4, mark: "✦", color: "#3d4442", description: "Arrange a moment. Keep it forever." },
    { id: "starfall", title: "Starfall", genre: "ADVENTURE · 1 PLAYER", image: PHOTO_2, mark: "✷", color: "#45546c", description: "A tiny journey through a big night." },
    { id: "slow-burn", title: "Slow Burn", genre: "STORY · SOLO", image: PHOTO_3, mark: "◇", color: "#554632", description: "Every choice has its own light." },
  ];
  const categories = ["All games", "Arcade", "Creative", "Puzzle", "Story"];
  const filtered = games.filter((game) => (category === "All games" || game.genre.toLowerCase().includes(category.toLowerCase())) && `${game.title} ${game.description}`.toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="page-content games-page"><div className="games-hero"><div className="games-hero-copy"><span className="rail-eyebrow">A SMALL ESCAPE, ANYTIME</span><h2>Play a little.<br /><em>Feel a lot.</em></h2><p>Good games for the in-between moments. Pick a world, take a breath, and see where you end up.</p><button type="button" onClick={() => { setCategory("All games"); setPlaying("little-planet"); onToast("Little Planet is opening in demo mode."); }}>Discover your next favorite <ArrowRight size={15} /></button></div><div className="game-feature-art"><Image src={PHOTO_5} alt="Featured game artwork" fill sizes="500px" unoptimized /><span className="feature-stamp">NOIR<br /><b>ARCADE</b><small>VOL. 01</small></span><div className="feature-art-shade" /></div></div><div className="game-library-toolbar"><div><span className="rail-eyebrow">THE PLAYROOM</span><h3>A good kind of distraction</h3></div><div className="game-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Find a game" aria-label="Search games" /></div></div><div className="game-categories">{categories.map((item) => <button className={category === item ? "active" : ""} key={item} type="button" onClick={() => setCategory(item)}>{item}</button>)}<span>100 LITTLE WORLDS AND COUNTING</span></div><div className="game-grid">{filtered.map((game) => <article className={`game-card ${playing === game.id ? "game-selected" : ""}`} key={game.id}><div className="game-art" style={{ backgroundColor: game.color }}><Image src={game.image} alt="" fill sizes="300px" unoptimized /><div className="game-art-scrim" /><span className="game-mark">{game.mark}</span><span className="game-genre">{game.genre}</span><button type="button" className="game-play" onClick={() => { setPlaying(game.id); onToast(`${game.title} is ready to launch — full games are coming soon.`); }} aria-label={`Play ${game.title}`}><Play size={17} fill="currentColor" /></button></div><div className="game-card-copy"><div><h4>{game.title}</h4><p>{game.description}</p></div><button type="button" onClick={() => onToast(`${game.title} added to your collection.`)} aria-label={`Save ${game.title}`}><Plus size={17} /></button></div></article>)}</div><div className="games-note"><Gamepad2 size={15} /> The NOIR library is a playful preview. Full games are rolling in soon.</div></div>
  );
}

function MusicView({ onToast }: { onToast: (message: string) => void }) {
  const [track, setTrack] = useState({ title: "Midnight Drive", artist: "NOIR Radio · After dark", url: "" });
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const fileInput = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const tracks = [
    { title: "Velvet Hour", artist: "Sable June", time: "3:42", cover: PHOTO_1 },
    { title: "The Long Way Home", artist: "Milo Grey", time: "4:06", cover: PHOTO_2 },
    { title: "Slow Motion", artist: "nori.wav", time: "3:18", cover: PHOTO_3 },
    { title: "Little Light", artist: "Sol & The City", time: "2:54", cover: PHOTO_6 },
    { title: "Nothing, Somewhere", artist: "Kairo Rivers", time: "4:20", cover: PHOTO_5 },
  ];
  const billboard = [
    { rank: "01", title: "Golden", artist: "Jill Scott", change: "↑ 2" },
    { rank: "02", title: "Birds of a Feather", artist: "Billie Eilish", change: "—" },
    { rank: "03", title: "Saturn", artist: "SZA", change: "↑ 1" },
    { rank: "04", title: "End of Beginning", artist: "Djo", change: "↓ 1" },
    { rank: "05", title: "Good Luck, Babe!", artist: "Chappell Roan", change: "NEW" },
  ];

  function togglePlay() {
    if (!track.url) {
      onToast("Upload a song from your device to play it here.");
      fileInput.current?.click();
      return;
    }
    if (playing) {
      audioRef.current?.pause();
      setPlaying(false);
    } else {
      void audioRef.current?.play().then(() => setPlaying(true)).catch(() => onToast("That audio file couldn’t be played."));
    }
  }

  function importAudio(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (track.url) URL.revokeObjectURL(track.url);
    setTrack({ title: file.name.replace(/\.[^/.]+$/, ""), artist: "Your library · This device", url: URL.createObjectURL(file) });
    setProgress(0);
    onToast("Added to your listening room.");
  }

  function selectTrack(item: (typeof tracks)[number]) {
    setTrack({ title: item.title, artist: `${item.artist} · NOIR Radio`, url: "" });
    setPlaying(false);
    setProgress(0);
  }

  return (
    <div className="page-content music-page"><div className="music-hero"><div className="music-hero-bg"><Image src={PHOTO_1} alt="Moody music portrait" fill sizes="1200px" unoptimized /></div><div className="music-hero-overlay" /><div className="music-hero-copy"><span className="rail-eyebrow"><Radio size={12} /> NOIR RADIO · A NEW FREQUENCY</span><h2>Soundtrack<br />to <em>your own thing.</em></h2><p>A little something for right now.</p><button className="play-feature-button" type="button" onClick={togglePlay}>{playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />} {playing ? "Pause your session" : "Play your session"}</button></div><div className="music-hero-disc"><Disc3 size={85} strokeWidth={0.8} /><span><Aperture size={24} /></span></div></div><div className="music-content-grid"><section className="music-discovery"><div className="section-heading"><div><span className="rail-eyebrow">A LITTLE OF EVERYTHING</span><h3>Now in rotation</h3></div><button type="button" className="text-link" onClick={() => onToast("You’re seeing all of this week’s picks.")}>See all <ArrowRight size={14} /></button></div><div className="track-table"><div className="track-table-head"><span>#</span><span>TITLE</span><span>TIME</span><span /></div>{tracks.map((item, index) => <button className={`track-row ${track.title === item.title ? "active" : ""}`} key={item.title} type="button" onClick={() => selectTrack(item)}><span className="track-number">{track.title === item.title && playing ? <Volume2 size={15} /> : String(index + 1).padStart(2, "0")}</span><span className="track-main"><span className="track-cover"><Image src={item.cover} alt="" fill sizes="44px" unoptimized /></span><span><b>{item.title}</b><small>{item.artist}</small></span></span><span className="track-length">{item.time}</span><span className="track-extra"><button type="button" aria-label={`Add ${item.title} to queue`} onClick={(event) => { event.stopPropagation(); onToast(`${item.title} added to your queue.`); }}><Plus size={16} /></button><button type="button" aria-label={`More about ${item.title}`} onClick={(event) => { event.stopPropagation(); onToast(`${item.title} · ${item.artist}`); }}><Ellipsis size={17} /></button></span></button>)}</div><button className="upload-music-button" type="button" onClick={() => fileInput.current?.click()}><Plus size={17} /><span><b>Bring your own sound</b><small>Upload a song from your device and play it here.</small></span><ArrowRight size={16} /></button><input ref={fileInput} className="visually-hidden" type="file" accept="audio/*" onChange={importAudio} /></section><aside className="billboard-card"><div className="billboard-heading"><span className="rail-eyebrow">THE HOT 100</span><span className="chart-badge">WEEKLY CHART</span></div><h3>The world’s<br /><em>listening to.</em></h3><p>Billboard Hot 100 · Demo chart</p>{billboard.map((item) => <div className="chart-row" key={item.rank}><span>{item.rank}</span><div><b>{item.title}</b><small>{item.artist}</small></div><i>{item.change}</i></div>)}<button className="text-link" type="button" onClick={() => onToast("Live charts need a music data connection.")}>View full chart <ArrowRight size={13} /></button></aside></div><div className="player-bar"><button className="player-cover" type="button" onClick={() => fileInput.current?.click()}><Image src={PHOTO_5} alt="Current cover" fill sizes="46px" unoptimized /></button><div className="player-track"><b>{track.title}</b><small>{track.artist}</small></div><button className="player-like" type="button" aria-label="Save track" onClick={() => onToast("Added to your likes.")}><Heart size={16} /></button><div className="player-center"><div className="player-controls"><button type="button" aria-label="Previous track" onClick={() => onToast("You’re at the start of your session.")}>◀|</button><button className="player-play" type="button" onClick={togglePlay} aria-label={playing ? "Pause" : "Play"}>{playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}</button><button type="button" aria-label="Next track" onClick={() => onToast("That’s the last track in this little session.")}>|▶</button></div><div className="player-progress"><small>{formatAudioTime(progress)}</small><input type="range" min="0" max={duration || 100} value={Math.min(progress, duration || 100)} onChange={(event) => { const value = Number(event.target.value); setProgress(value); if (audioRef.current) audioRef.current.currentTime = value; }} aria-label="Track position" /><small>{formatAudioTime(duration)}</small></div></div><div className="player-volume"><Volume2 size={16} /><input type="range" min="0" max="100" defaultValue="70" aria-label="Volume" /></div><audio ref={audioRef} src={track.url || undefined} onTimeUpdate={(event) => setProgress(event.currentTarget.currentTime)} onLoadedMetadata={(event) => setDuration(event.currentTarget.duration)} onEnded={() => setPlaying(false)} />
    </div></div>
  );
}

function formatAudioTime(seconds: number) {
  if (!Number.isFinite(seconds)) return "0:00";
  return `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`;
}

function NotificationsView({ onToast }: { onToast: (message: string) => void }) {
  const [notifications, setNotifications] = useState([
    { id: "n1", type: "like", name: "Mika Sol", handle: "mika.sol", avatar: PHOTO_6, text: "and 18 others loved your photo.", time: "2m", image: PHOTO_3, unread: true },
    { id: "n2", type: "follow", name: "Nori James", handle: "norijames", avatar: PHOTO_4, text: "started following you.", time: "18m", image: "", unread: true },
    { id: "n3", type: "comment", name: "Luna Vale", handle: "luna.vale", avatar: PHOTO_1, text: "left a little love: ‘the light in this!! 🖤’", time: "1h", image: PHOTO_3, unread: false },
    { id: "n4", type: "mention", name: "Kai Rivers", handle: "kai.rivers", avatar: PHOTO_5, text: "mentioned you in a story.", time: "3h", image: PHOTO_1, unread: false },
    { id: "n5", type: "like", name: "Remy Arlo", handle: "remyarlo", avatar: PHOTO_2, text: "saved your ‘After Hours’ edit.", time: "5h", image: PHOTO_4, unread: false },
  ]);
  const unreadCount = notifications.filter((item) => item.unread).length;
  return (
    <div className="page-content notifications-page"><div className="notifications-heading"><div><span className="rail-eyebrow">LITTLE SIGNS YOU’RE OUT THERE</span><h2>A little love<br /><em>goes a long way.</em></h2><p>Every like, note, and new connection — all gathered in one place.</p></div><div className="notification-orbit"><Bell size={28} /><span>{unreadCount || "✦"}</span></div></div><div className="notifications-card"><div className="notifications-toolbar"><div><b>Activity</b><span>{unreadCount} new</span></div><button type="button" onClick={() => { setNotifications((current) => current.map((item) => ({ ...item, unread: false }))); onToast("You’re all caught up."); }}>Mark all as read <CheckCheck size={15} /></button></div>{notifications.map((item) => <article className={`notification-row ${item.unread ? "unread" : ""}`} key={item.id}><div className="notification-avatar"><Avatar src={item.avatar} name={item.name} size={44} /><span className={`notification-kind kind-${item.type}`}>{item.type === "like" ? <Heart size={10} fill="currentColor" /> : item.type === "follow" ? <UserRoundPlus size={10} /> : item.type === "comment" ? <MessageCircle size={10} /> : <Sparkles size={10} />}</span></div><div className="notification-copy"><p><b>{item.name}</b> <span className="notification-handle">@{item.handle}</span> {item.text}</p><small>{item.time} ago</small></div>{item.image ? <button className="notification-preview" type="button" aria-label="View related photo" onClick={() => onToast("Opening a frame from your community.")}><Image src={item.image} alt="Related post" fill sizes="54px" unoptimized /></button> : <button className="notification-follow" type="button" onClick={() => onToast(`You’re now connected with ${item.name}.`)}>Follow</button>}</article>)}</div><div className="notifications-footnote"><CircleHelp size={15} /> Your activity stays yours. Manage notifications any time in settings.</div></div>
  );
}

function ProfileView({ onToast }: { onToast: (message: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [bio, setBio] = useState("Collecting little moments, making them mean a little more. Photographer & daydreamer.");
  const [draft, setDraft] = useState(bio);
  const [tab, setTab] = useState("Frames");
  const profileFrames = [PHOTO_1, PHOTO_4, PHOTO_6, PHOTO_2, PHOTO_3, PHOTO_5];
  function saveBio() {
    setBio(draft.trim() || "A little more of me, one frame at a time.");
    setEditing(false);
    onToast("Your profile feels a little more like you.");
  }
  return (
    <div className="page-content profile-page"><section className="profile-cover"><Image src={PHOTO_5} alt="Profile cover" fill sizes="1200px" unoptimized /><div className="profile-cover-shade" /><div className="profile-cover-word">A WORLD OF YOUR OWN <span>✦</span></div><button type="button" onClick={() => onToast("Choose a new cover image from your device.")}><ImagePlus size={14} /> Edit cover</button></section><section className="profile-main-card"><div className="profile-main-top"><Avatar src={MY_AVATAR} name="Amara Vale" size={90} className="profile-avatar" /><div className="profile-actions"><button type="button" className="subtle-button" onClick={() => { setDraft(bio); setEditing((current) => !current); }}><PencilLine size={15} /> {editing ? "Cancel" : "Edit profile"}</button><button type="button" className="icon-button profile-share" aria-label="Share profile" onClick={() => onToast("Profile link copied to clipboard.")}><Share2 size={16} /></button></div></div><div className="profile-heading"><div><h2>Amara Vale <span className="verified-dot"><Check size={9} /></span></h2><span className="profile-handle">@amara.vale <i>·</i> Brooklyn, NY</span></div><div className="profile-stats"><span><b>128</b><small>frames</small></span><span><b>8.4k</b><small>followers</small></span><span><b>612</b><small>following</small></span></div></div>{editing ? <div className="bio-editor"><textarea value={draft} onChange={(event) => setDraft(event.target.value)} maxLength={160} aria-label="Edit your biography" /><div><small>{draft.length}/160</small><button className="gold-button" type="button" onClick={saveBio}>Save changes <Check size={14} /></button></div></div> : <p className="profile-bio">{bio}</p>}<div className="profile-links"><button type="button" onClick={() => onToast("Your website link is ready to edit.")}><Globe2 size={15} /> amara-vale.com</button><span><Link2 size={14} /> CONNECTED ELSEWHERE</span></div><div className="social-link-grid">{SOCIAL_LINKS.map((item) => <a href={item.href} target="_blank" rel="noreferrer" key={item.label}><span className="social-symbol">{item.symbol}</span><span><b>{item.label}</b><small>{item.handle}</small></span><ExternalLink size={13} /></a>)}</div></section><div className="profile-content-toolbar"><div className="profile-tabs">{["Frames", "Saved", "Tagged"].map((item) => <button className={tab === item ? "active" : ""} key={item} type="button" onClick={() => setTab(item)}>{item}</button>)}</div><button className="profile-sort" type="button" onClick={() => onToast("Your frames are sorted by newest first.")}>Newest first <ChevronDown size={14} /></button></div><div className="profile-grid">{profileFrames.map((image, index) => <button className="profile-grid-photo" type="button" key={image} onClick={() => onToast(`Frame ${String(index + 1).padStart(2, "0")} · shared with your world.`)}><Image src={image} alt={`Amara Vale frame ${index + 1}`} fill sizes="(max-width: 700px) 30vw, 300px" unoptimized /><span><Heart size={14} fill="currentColor" /> {142 + index * 73}</span></button>)}</div></div>
  );
}

function Modal({ children, onClose, wide = false }: { children: ReactNode; onClose: () => void; wide?: boolean }) {
  useEffect(() => {
    function handleKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose]);
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className={`modal-card ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true">{children}</section></div>;
}

export default function NoirApp() {
  const [view, setView] = useState<ViewKey>("home");
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [search, setSearch] = useState("");
  const [likedIds, setLikedIds] = useState<Set<string>>(() => new Set());
  const [savedIds, setSavedIds] = useState<Set<string>>(() => new Set());
  const [showComposer, setShowComposer] = useState(false);
  const [draft, setDraft] = useState("");
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [posting, setPosting] = useState(false);
  const [commentsTarget, setCommentsTarget] = useState<Post | null>(null);
  const [commentDraft, setCommentDraft] = useState("");
  const [comments, setComments] = useState<Record<string, string[]>>({
    "demo-1": ["The light in this is unreal ✨", "This feels like the opening shot of a film.", "after hours forever 🖤"],
    "demo-2": ["Every time. You always find the quiet."],
  });
  const [activeStory, setActiveStory] = useState<(typeof STORIES)[number] | null>(null);
  const [toast, setToast] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const toastTimer = useRef<number | null>(null);
  const uploadInput = useRef<HTMLInputElement>(null);
  const details = VIEW_DETAILS[view];

  useEffect(() => {
    let isCurrent = true;
    fetch("/api/posts")
      .then((response) => response.ok ? response.json() as Promise<{ posts: ApiPost[] }> : null)
      .then((data) => {
        if (isCurrent && data?.posts?.length) {
          const savedPosts = data.posts.map((post) => mapApiPost(post));
          setPosts((current) => [...savedPosts, ...current.filter((post) => !savedPosts.some((saved) => saved.id === post.id))]);
        }
      })
      .catch(() => undefined);
    return () => { isCurrent = false; };
  }, []);

  useEffect(() => () => {
    if (toastTimer.current !== null) window.clearTimeout(toastTimer.current);
  }, []);

  function showToast(message: string) {
    setToast(message);
    if (toastTimer.current !== null) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 3200);
  }

  function navigate(destination: ViewKey) {
    setView(destination);
    setMenuOpen(false);
    setSearch("");
  }

  function toggleLike(id: string) {
    setLikedIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleSave(id: string) {
    setSavedIds((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function handleUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (file) setUploadPreview(URL.createObjectURL(file));
  }

  async function publishPost() {
    const content = draft.trim() || (uploadPreview ? "A little something from my camera roll. ✦" : "");
    if (!content) {
      showToast("Add a thought or a frame before sharing.");
      return;
    }
    setPosting(true);
    try {
      const response = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      if (!response.ok) {
        const data = await response.json() as { error?: string };
        throw new Error(data.error || "Your post could not be saved.");
      }
      const data = await response.json() as { post: ApiPost };
      setPosts((current) => [mapApiPost(data.post, uploadPreview ?? undefined), ...current]);
      showToast(uploadPreview ? "Shared with your world. The image preview stays on this device." : "Your thought is out in the world.");
    } catch (error) {
      const localPost: Post = {
        id: `local-${Date.now()}`,
        name: "Amara Vale",
        handle: "amara.vale",
        avatar: MY_AVATAR,
        time: "just now",
        text: content,
        image: uploadPreview ?? undefined,
        alt: "A new frame from Amara Vale",
        tags: ["#mynoir"],
        likes: 0,
        comments: 0,
      };
      setPosts((current) => [localPost, ...current]);
      showToast(error instanceof Error ? `${error.message} Kept in this session.` : "Kept in this session.");
    } finally {
      setPosting(false);
      setDraft("");
      setUploadPreview(null);
      setShowComposer(false);
      if (uploadInput.current) uploadInput.current.value = "";
    }
  }

  function submitComment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!commentsTarget || !commentDraft.trim()) return;
    const text = commentDraft.trim();
    setComments((current) => ({ ...current, [commentsTarget.id]: [...(current[commentsTarget.id] ?? []), text] }));
    setPosts((current) => current.map((post) => post.id === commentsTarget.id ? { ...post, comments: post.comments + 1 } : post));
    setCommentDraft("");
  }

  async function sharePost(post: Post) {
    try {
      await navigator.clipboard.writeText(`${post.name} on NOIR — ${post.text}`);
      showToast("A little link to this frame is copied.");
    } catch {
      showToast("Share this frame with someone who gets it.");
    }
  }

  const homePosts = useMemo(() => posts, [posts]);
  const primaryNav: { label: string; key: ViewKey; icon: LucideIcon; badge?: string }[] = [
    { label: "Home", key: "home", icon: Compass },
    { label: "Discover", key: "explore", icon: Search },
    { label: "Messages", key: "messages", icon: MessageSquare, badge: "2" },
    { label: "Notifications", key: "notifications", icon: Bell },
  ];
  const makeNav: { label: string; key: ViewKey; icon: LucideIcon }[] = [
    { label: "NOIR Studio", key: "studio", icon: Clapperboard },
    { label: "NOIR Camera", key: "camera", icon: Camera },
    { label: "NOIR AI", key: "ai", icon: Sparkles },
  ];
  const exploreNav: { label: string; key: ViewKey; icon: LucideIcon }[] = [
    { label: "Ideas", key: "inspiration", icon: Bookmark },
    { label: "Music", key: "music", icon: Headphones },
    { label: "Games", key: "games", icon: Gamepad2 },
  ];

  return (
    <div className="noir-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <button className="brand-lockup" type="button" onClick={() => navigate("home")} aria-label="NOIR home"><span className="brand-star">✦</span><span className="brand-word">NOIR</span><span className="brand-period">.</span><span className="brand-caption">YOUR WORLD. YOUR LENS.</span></button>
        <div className="sidebar-rule" />
        <div className="sidebar-label">YOUR SPACE</div>
        <nav className="side-nav">{primaryNav.map((item) => <SidebarItem key={item.key} label={item.label} icon={item.icon} active={view === item.key} badge={item.badge} onClick={() => navigate(item.key)} />)}</nav>
        <div className="sidebar-label sidebar-label-spaced">MAKE SOMETHING</div>
        <nav className="side-nav">{makeNav.map((item) => <SidebarItem key={item.key} label={item.label} icon={item.icon} active={view === item.key} accent={item.key === "ai"} onClick={() => navigate(item.key)} />)}</nav>
        <div className="sidebar-label sidebar-label-spaced">WHENEVER YOU FEEL</div>
        <nav className="side-nav">{exploreNav.map((item) => <SidebarItem key={item.key} label={item.label} icon={item.icon} active={view === item.key} onClick={() => navigate(item.key)} />)}</nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-now-playing"><span className="mini-album"><Image src={PHOTO_5} alt="" fill sizes="36px" unoptimized /></span><span><b>Midnight Drive</b><small>NOIR Radio</small></span><button type="button" aria-label="Open music" onClick={() => navigate("music")}><Play size={13} fill="currentColor" /></button></div>
        <button className={`sidebar-profile ${view === "profile" ? "active" : ""}`} type="button" onClick={() => navigate("profile")}><Avatar src={MY_AVATAR} name="Amara Vale" size={39} /><span><b>Amara Vale</b><small>Personal space</small></span><Ellipsis size={18} /></button>
        <div className="sidebar-legal"><span>MADE FOR THE FEELING</span><span>NOIR © 2025</span></div>
      </aside>

      <div className="main-shell">
        <header className="topbar"><button className="mobile-menu-button" type="button" aria-label="Open navigation" onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button><button className="mobile-brand" type="button" onClick={() => navigate("home")}>NOIR<span>.</span></button><div className="topbar-context"><span className="topbar-eyebrow">{details.eyebrow}</span><h1>{details.title}</h1></div><div className="topbar-search"><Search size={16} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search NOIR" aria-label="Search NOIR" /><kbd>⌘ K</kbd></div><div className="topbar-actions"><IconButton label="Open messages" onClick={() => navigate("messages")}><MessageSquare size={17} /><i className="action-dot" /></IconButton><IconButton label="Open notifications" onClick={() => navigate("notifications")}><Bell size={18} /></IconButton><button className="topbar-avatar-button" type="button" onClick={() => navigate("profile")} aria-label="Open profile"><Avatar src={MY_AVATAR} name="Amara Vale" size={37} /><ChevronDown size={13} /></button></div></header>
        <main className="main-content" key={view}>
          {view === "home" ? <HomeView posts={homePosts} search={search} likedIds={likedIds} savedIds={savedIds} onLike={toggleLike} onComment={(post) => setCommentsTarget(post)} onSave={toggleSave} onShare={(post) => void sharePost(post)} onCompose={() => setShowComposer(true)} onStory={setActiveStory} onNavigate={navigate} /> : null}
          {view === "explore" ? <ExploreView onToast={showToast} savedIds={savedIds} onSave={toggleSave} /> : null}
          {view === "messages" ? <MessagesView onToast={showToast} /> : null}
          {view === "studio" ? <StudioView onToast={showToast} /> : null}
          {view === "camera" ? <CameraView onToast={showToast} /> : null}
          {view === "ai" ? <AiView onToast={showToast} /> : null}
          {view === "inspiration" ? <InspirationView onToast={showToast} savedIds={savedIds} onSave={toggleSave} /> : null}
          {view === "games" ? <GamesView onToast={showToast} /> : null}
          {view === "music" ? <MusicView onToast={showToast} /> : null}
          {view === "notifications" ? <NotificationsView onToast={showToast} /> : null}
          {view === "profile" ? <ProfileView onToast={showToast} /> : null}
        </main>
        <nav className="mobile-bottom-nav" aria-label="Mobile navigation">{[{ key: "home" as const, label: "Home", icon: Compass }, { key: "explore" as const, label: "Discover", icon: Search }, { key: "messages" as const, label: "DMs", icon: MessageSquare }, { key: "ai" as const, label: "NOIR AI", icon: Sparkles }, { key: "profile" as const, label: "You", icon: Users }].map((item) => <button className={view === item.key ? "active" : ""} key={item.key} type="button" onClick={() => navigate(item.key)}><item.icon size={19} /><span>{item.label}</span></button>)}</nav>
      </div>

      {showComposer ? <Modal onClose={() => { setShowComposer(false); setDraft(""); setUploadPreview(null); }} wide><div className="modal-header"><div><span className="rail-eyebrow">A LITTLE SOMETHING FROM YOU</span><h2>Share a frame.</h2></div><button className="quiet-icon" type="button" aria-label="Close" onClick={() => setShowComposer(false)}><X size={19} /></button></div><div className="composer-modal-body"><Avatar src={MY_AVATAR} name="Amara Vale" size={44} /><div><b>Amara Vale <span>· posting to everyone</span></b><textarea value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="A thought, a feeling, a frame…" maxLength={600} autoFocus aria-label="Write a post" /></div></div>{uploadPreview ? <div className="composer-image-preview"><Image src={uploadPreview} alt="Selected post preview" fill sizes="500px" unoptimized /><button type="button" aria-label="Remove selected photo" onClick={() => { URL.revokeObjectURL(uploadPreview); setUploadPreview(null); }}><X size={15} /></button></div> : null}<div className="composer-modal-footer"><div className="composer-upload-actions"><button type="button" onClick={() => uploadInput.current?.click()}><ImagePlus size={17} /> Photo</button><button type="button" onClick={() => setDraft((value) => `${value}${value ? " " : ""}✨`)}><Sparkles size={16} /> Feeling</button><span>Media upload preview only</span></div><input ref={uploadInput} type="file" accept="image/*" className="visually-hidden" onChange={handleUpload} /><span className="character-count">{draft.length}/600</span><button className="gold-button" type="button" onClick={() => void publishPost()} disabled={posting}>{posting ? <LoaderCircle className="spin" size={15} /> : <Send size={15} />} {posting ? "Sharing…" : "Share with NOIR"}</button></div></Modal> : null}

      {commentsTarget ? <Modal onClose={() => { setCommentsTarget(null); setCommentDraft(""); }}><div className="modal-header"><div><span className="rail-eyebrow">A GOOD CONVERSATION</span><h2>Leave a little love.</h2></div><button className="quiet-icon" type="button" aria-label="Close comments" onClick={() => setCommentsTarget(null)}><X size={19} /></button></div><div className="comment-post-preview"><Avatar src={commentsTarget.avatar} name={commentsTarget.name} size={36} /><div><b>{commentsTarget.name}</b><p>{commentsTarget.text}</p></div></div><div className="comment-list">{(comments[commentsTarget.id] ?? []).map((comment, index) => <div className="comment-item" key={`${comment}-${index}`}><Avatar src={index % 2 ? PHOTO_5 : PHOTO_6} name={index % 2 ? "Kai Rivers" : "Mika Sol"} size={32} /><div><b>{index % 2 ? "kai.rivers" : "mika.sol"}</b><p>{comment}</p><small>{index === 0 ? "12m" : "8m"} · <button type="button" onClick={() => showToast("Thanks for the love.")}>Reply</button></small></div><button type="button" aria-label="Like comment" onClick={() => showToast("Comment liked.")}><Heart size={14} /></button></div>)}{(comments[commentsTarget.id] ?? []).length === 0 ? <div className="comment-empty">Start the conversation. Be the first to leave a little love.</div> : null}</div><form className="comment-compose" onSubmit={submitComment}><Avatar src={MY_AVATAR} name="Amara Vale" size={34} /><input value={commentDraft} onChange={(event) => setCommentDraft(event.target.value)} placeholder="Add a comment…" aria-label="Write a comment" /><button type="submit" disabled={!commentDraft.trim()}><Send size={16} /></button></form></Modal> : null}

      {activeStory ? <Modal onClose={() => setActiveStory(null)}><div className="story-viewer"><Image src={activeStory.image} alt={`${activeStory.name}'s story`} fill sizes="480px" unoptimized /><div className="story-viewer-shade" /><div className="story-progress"><i /><i /><i /></div><div className="story-viewer-header"><Avatar src={activeStory.image} name={activeStory.name} size={34} /><b>{activeStory.own ? "Your story" : activeStory.name}</b><span>now</span><button type="button" aria-label="Close story" onClick={() => setActiveStory(null)}><X size={19} /></button></div><div className="story-viewer-copy"><span>NOIR / YOUR WORLD</span><h2>{activeStory.own ? "Make this moment yours." : "A moment worth keeping."}</h2><p>{activeStory.own ? "Your story is a little space to share what you’re seeing." : "Little moments. Different lenses. Same world."}</p>{activeStory.own ? <button type="button" onClick={() => { setActiveStory(null); setShowComposer(true); }}>Add to your story <Plus size={14} /></button> : <button type="button" onClick={() => { setActiveStory(null); navigate("messages"); }}>Send a little love <MessageCircle size={14} /></button>}</div></div></Modal> : null}

      {toast ? <div className="toast-message" role="status"><span><Check size={14} /></span>{toast}<button type="button" aria-label="Dismiss message" onClick={() => setToast("")}><X size={14} /></button></div> : null}
    </div>
  );
}
