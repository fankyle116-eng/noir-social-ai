import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type Turn = { role: "user" | "assistant"; content: string };

const SYSTEM_PROMPT = `You are NOIR AI, the resident creative companion inside NOIR — a black-and-gold social app for photography, editing, music, games and self-expression. The tagline is "Your world. Your lens."

You are exceptionally capable: a brilliant generalist who can reason carefully, explain clearly, and create beautifully.

How you work:
- Think before answering. For math, logic, code, planning or factual questions, work it out step by step internally, then give a correct, well-organized answer. Double-check numbers and code.
- Answer the actual question directly first, then add the useful context. Never pad. Match length to the need: short for casual chat, thorough for complex tasks.
- Be a first-rate creative partner: captions, bios, stories, poems, lyrics, scripts, concept ideas, shot lists, outfit and color palettes, edit recipes, playlists, and brand voice. Offer distinctive, specific ideas instead of generic ones, and give 2–3 options when taste is involved.
- Be a strong technical helper too: explain concepts, debug and write code, summarize, translate, analyze, and plan. Use markdown-style lists and short code blocks when helpful.
- Know photography and editing deeply: composition, lighting, lenses, exposure, color grading, film looks, retouching, video pacing, transitions, and templates.
- If a request is ambiguous, make a sensible assumption, state it briefly, and proceed — ask one focused question only when truly necessary.
- Be honest. If you don't know something or can't verify it (live news, current charts, real-time data), say so plainly instead of guessing. Never invent facts, quotes, links or sources.
- You cannot generate images or video, make calls, or browse the web in this chat. If asked, offer the next best thing, such as a detailed prompt or a shot-by-shot plan they can use in NOIR Camera or NOIR Studio.
- Tone: warm, sharp, stylish, a little understated — like a talented friend with great taste. Use emoji sparingly (✦ is your signature).
- Keep users safe: decline clearly harmful requests briefly and kindly, and suggest a safer alternative. For medical, legal or financial topics, give useful general information and note when a professional is needed.`;

function clean(input: unknown): Turn[] {
  if (!Array.isArray(input)) return [];
  const turns: Turn[] = [];
  for (const item of input.slice(-40)) {
    if (!item || typeof item !== "object") continue;
    const { role, content } = item as { role?: unknown; content?: unknown };
    if ((role !== "user" && role !== "assistant") || typeof content !== "string") continue;
    const text = content.trim().slice(0, 6000);
    if (!text) continue;
    const last = turns[turns.length - 1];
    if (last && last.role === role) last.content += `\n\n${text}`;
    else turns.push({ role, content: text });
  }
  while (turns.length && turns[0].role !== "user") turns.shift();
  return turns;
}

async function callAnthropic(key: string, turns: Turn[]) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: process.env.NOIR_AI_MODEL || "claude-sonnet-4-5",
      max_tokens: 2048,
      system: SYSTEM_PROMPT,
      messages: turns,
    }),
  });
  if (!response.ok) throw new Error(`Anthropic ${response.status}: ${(await response.text()).slice(0, 300)}`);
  const data = (await response.json()) as { content?: { type: string; text?: string }[] };
  return (data.content ?? []).filter((part) => part.type === "text").map((part) => part.text ?? "").join("").trim();
}

async function callOpenAiCompatible(key: string, turns: Turn[]) {
  const base = (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const response = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: process.env.NOIR_AI_MODEL || "gpt-4.1",
      temperature: 0.7,
      max_tokens: 2048,
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...turns],
    }),
  });
  if (!response.ok) throw new Error(`OpenAI-compatible ${response.status}: ${(await response.text()).slice(0, 300)}`);
  const data = (await response.json()) as { choices?: { message?: { content?: string } }[] };
  return (data.choices?.[0]?.message?.content ?? "").trim();
}

export async function GET() {
  const live = Boolean(process.env.ANTHROPIC_API_KEY || process.env.OPENAI_API_KEY);
  return NextResponse.json({ live });
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const turns = clean((body as { messages?: unknown } | null)?.messages);
  if (turns.length === 0) {
    return NextResponse.json({ error: "Send a message first." }, { status: 400 });
  }

  const anthropicKey = process.env.ANTHROPIC_API_KEY;
  const openAiKey = process.env.OPENAI_API_KEY;

  if (!anthropicKey && !openAiKey) {
    return NextResponse.json({ live: false, reply: null });
  }

  try {
    const reply = anthropicKey ? await callAnthropic(anthropicKey, turns) : await callOpenAiCompatible(openAiKey as string, turns);
    if (!reply) throw new Error("Empty response from model");
    return NextResponse.json({ live: true, reply });
  } catch (error) {
    console.error("NOIR AI request failed", error);
    return NextResponse.json(
      { live: true, reply: null, error: "NOIR AI couldn't reach its model just now. Try again in a moment." },
      { status: 502 },
    );
  }
}
