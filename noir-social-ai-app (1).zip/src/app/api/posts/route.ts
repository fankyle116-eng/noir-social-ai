import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { posts } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(posts).orderBy(desc(posts.createdAt)).limit(30);
    return NextResponse.json({ posts: rows });
  } catch (error) {
    console.error("Could not load NOIR posts", error);
    return NextResponse.json({ error: "Posts are temporarily unavailable." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || !("content" in body)) {
      return NextResponse.json({ error: "Add a thought before sharing." }, { status: 400 });
    }

    const content = typeof body.content === "string" ? body.content.trim() : "";
    if (!content || content.length > 600) {
      return NextResponse.json(
        { error: "Posts must be between 1 and 600 characters." },
        { status: 400 },
      );
    }

    const [post] = await db
      .insert(posts)
      .values({
        authorName: "Amara Vale",
        authorHandle: "amara.vale",
        avatarUrl: "",
        content,
      })
      .returning();

    return NextResponse.json({ post }, { status: 201 });
  } catch (error) {
    console.error("Could not create NOIR post", error);
    return NextResponse.json({ error: "Your post could not be saved just now." }, { status: 500 });
  }
}
