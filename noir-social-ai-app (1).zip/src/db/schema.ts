import {
  index,
  integer,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const posts = pgTable(
  "noir_posts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    authorName: varchar("author_name", { length: 120 }).notNull(),
    authorHandle: varchar("author_handle", { length: 60 }).notNull(),
    avatarUrl: text("avatar_url").notNull().default(""),
    content: text("content").notNull(),
    imageUrl: text("image_url"),
    likes: integer("likes").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("noir_posts_created_at_idx").on(table.createdAt)],
);
